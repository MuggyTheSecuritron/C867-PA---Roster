#pragma once
enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };
enum daysInCourseID { ONE, TWO, THREE, AVG };