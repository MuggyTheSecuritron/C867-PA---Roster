#pragma once
enum DegreeProgram { SECURITY, NETWORK, SOFTWARE, BONK };
enum daysInCourseID { ONE, TWO, THREE, AVG };